-- Default 128
-- 3x
UPDATE Improvements	SET TilesPerGoody = 32, GoodyRange = 2 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';