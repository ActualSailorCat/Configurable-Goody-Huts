-- Default 128
-- 2x
UPDATE Improvements	SET TilesPerGoody = 64, GoodyRange = 2 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';