-- Default 128
-- 1.5x
UPDATE Improvements	SET TilesPerGoody = 112 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';