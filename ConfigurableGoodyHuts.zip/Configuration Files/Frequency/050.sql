-- Default 128
-- 0.5x
UPDATE Improvements	SET TilesPerGoody = 192 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';