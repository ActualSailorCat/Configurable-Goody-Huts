-- Default 128
-- 0.25x
UPDATE Improvements	SET TilesPerGoody = 224 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';