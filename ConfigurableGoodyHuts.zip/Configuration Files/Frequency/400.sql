-- Default 128
-- 4x
UPDATE Improvements	SET TilesPerGoody = 16, GoodyRange = 1 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';