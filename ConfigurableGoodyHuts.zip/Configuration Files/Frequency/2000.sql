-- Default 128
-- 20x
UPDATE Improvements	SET TilesPerGoody = 2, GoodyRange = 1 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';