-- Default 128
-- 5x
UPDATE Improvements	SET TilesPerGoody = 8, GoodyRange = 1 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';