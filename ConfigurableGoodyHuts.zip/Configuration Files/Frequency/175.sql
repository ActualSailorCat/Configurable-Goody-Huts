-- Default 128
-- 1.75x
UPDATE Improvements	SET TilesPerGoody = 80 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';