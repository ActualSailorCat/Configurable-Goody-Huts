-- Default 128
-- 0.75x
UPDATE Improvements	SET TilesPerGoody = 160 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';