-- Default 128
-- 1.5x
UPDATE Improvements	SET TilesPerGoody = 96 WHERE ImprovementType = 'IMPROVEMENT_GOODY_HUT';